import 'dart:convert';
import 'package:http/http.dart' as http;

class GrammarService {
  final http.Client _client;
  GrammarService({http.Client? client}) : _client = client ?? http.Client();

  Future<bool> isSupported() async {
    return true;
  }

  Future<String> correct({
    required String text,
    String language = 'auto',
  }) async {
    final normalized = _normalizeLang(language);
    final prepared = _prepareForCorrection(text);
    final chunks = _chunkText(prepared, maxChunkChars: 3500);
    final out = StringBuffer();

    for (var i = 0; i < chunks.length; i++) {
      final corrected = await _correctChunk(chunks[i], normalized);
      out.write(corrected);
      if (i != chunks.length - 1) {
        out.write('\n\n');
      }
    }

    return _postProcessCorrectedText(out.toString());
  }

  Future<String> _correctChunk(String text, String language) async {
    final uri = Uri.parse('https://api.languagetool.org/v2/check');
    final response = await _client.post(
      uri,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'text': text,
        'language': language,
        'enabledOnly': 'false',
      },
    ).timeout(const Duration(seconds: 30));

    if (response.statusCode != 200) {
      throw Exception('Falha ao corrigir gramática (HTTP ${response.statusCode}).');
    }

    final data = jsonDecode(utf8.decode(response.bodyBytes));
    final matches = (data['matches'] as List?) ?? const [];
    if (matches.isEmpty) return text;

    final sorted = matches.whereType<Map>().toList()
      ..sort((a, b) => ((b['offset'] ?? 0) as int).compareTo(((a['offset'] ?? 0) as int)));

    var result = text;
    for (final m in sorted) {
      final replacements = (m['replacements'] as List?) ?? const [];
      if (replacements.isEmpty) continue;
      final replacement = (replacements.first is Map) ? ((replacements.first['value'] ?? '').toString()) : '';
      if (replacement.isEmpty) continue;
      final offset = ((m['offset'] ?? 0) as int);
      final length = ((m['length'] ?? 0) as int);
      if (offset < 0 || length < 0 || offset + length > result.length) continue;
      result = result.replaceRange(offset, offset + length, replacement);
    }
    return result;
  }

  String _normalizeLang(String language) {
    final l = language.trim().toLowerCase();
    switch (l) {
      case 'pt':
      case 'pt-br':
        return 'pt-BR';
      case 'en':
        return 'en-US';
      case 'fr':
        return 'fr';
      case 'de':
        return 'de-DE';
      case 'it':
        return 'it';
      case 'cs':
        return 'cs';
      case 'es':
        return 'es';
      case 'ja':
        return 'ja';
      default:
        return 'auto';
    }
  }

  String _prepareForCorrection(String input) {
    var text = input.trim();
    if (text.isEmpty) return text;

    text = text.replaceAll('\r\n', '\n');
    text = text.replaceAll('\r', '\n');
    text = text.replaceAll(RegExp(r'[\t\f\v]+'), ' ');
    text = text.replaceAll(RegExp(r'\u00A0'), ' ');
    text = text.replaceAll(RegExp(r'[ ]{2,}'), ' ');
    text = _joinBrokenLines(text);
    text = _removeRepeatedFillers(text);
    text = _removeImmediateDuplicateWords(text);
    text = _normalizePunctuationSpacing(text);
    text = text.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return text.trim();
  }

  String _postProcessCorrectedText(String input) {
    var text = input.trim();
    if (text.isEmpty) return text;

    text = _removeRepeatedFillers(text);
    text = _removeImmediateDuplicateWords(text);
    text = _normalizePunctuationSpacing(text);
    text = _capitalizeSentenceStarts(text);
    text = text.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return text.trim();
  }

  String _joinBrokenLines(String input) {
    final lines = input.split('\n');
    if (lines.length <= 1) return input;

    final out = StringBuffer();

    for (var i = 0; i < lines.length; i++) {
      final current = lines[i].trim();
      if (current.isEmpty) {
        final currentText = out.toString().trimRight();
        if (currentText.isNotEmpty && !currentText.endsWith('\n\n')) {
          out.write('\n\n');
        }
        continue;
      }

      if (out.isEmpty) {
        out.write(current);
        continue;
      }

      final previous = out.toString().trimRight();
      final previousEndsSentence = RegExp(r'[\.!\?…:;。！？]$').hasMatch(previous);
      final looksLikeContinuation = current.isNotEmpty &&
          (RegExp(r'^[a-zà-ÿ0-9]').hasMatch(current) || current.startsWith(',') || current.startsWith(')'));

      if (previousEndsSentence || !looksLikeContinuation) {
        out.write('\n');
        out.write(current);
      } else {
        out.write(' ');
        out.write(current);
      }
    }

    return out.toString();
  }

  String _removeRepeatedFillers(String input) {
    var text = input;

    const singleWordFillers = <String>[
      'é', 'eh', 'ahn', 'ah', 'hum', 'hmm', 'uh', 'um', 'er', 'emm', 'tipo', 'né', 'bom'
    ];

    for (final filler in singleWordFillers) {
      final escaped = RegExp.escape(filler);
      final repeatedPattern = RegExp(
        '(?:(^)|([,;:\-–—\(\[]|\s))($escaped)(?:(\s*[,;:\-–—]?\s*)($escaped)){1,}(?=\b|[.!?…]|\n|\$)',
        caseSensitive: false,
        unicode: true,
      );
      text = text.replaceAllMapped(repeatedPattern, (m) {
        final prefixA = m.group(1) ?? '';
        final prefixB = m.group(2) ?? '';
        final fillerValue = m.group(3) ?? filler;
        return '$prefixA$prefixB$fillerValue';
      });
    }

    text = text.replaceAllMapped(
      RegExp(r'\b([A-Za-zÀ-ÿ]{1,12})\b(?:\s*,\s*\1\b){1,}', caseSensitive: false, unicode: true),
      (m) => m.group(1) ?? '',
    );

    return text;
  }

  String _removeImmediateDuplicateWords(String input) {
    var text = input;

    final duplicateWord = RegExp(
      r'\b([A-Za-zÀ-ÿ0-9]+)\b(?:\s+\1\b)+',
      caseSensitive: false,
      unicode: true,
    );

    while (duplicateWord.hasMatch(text)) {
      text = text.replaceAllMapped(duplicateWord, (m) => m.group(1) ?? '');
    }

    final duplicateWithComma = RegExp(
      r'\b([A-Za-zÀ-ÿ0-9]+)\b(?:\s*,\s*\1\b)+',
      caseSensitive: false,
      unicode: true,
    );

    while (duplicateWithComma.hasMatch(text)) {
      text = text.replaceAllMapped(duplicateWithComma, (m) => m.group(1) ?? '');
    }

    return text;
  }

  String _normalizePunctuationSpacing(String input) {
    var text = input;
    text = text.replaceAll(RegExp(r'\s+([,.;:!?…])'), r'$1');
    text = text.replaceAll(RegExp(r'([,;:!?…])(?!\s|\n|$)'), r'$1 ');
    text = text.replaceAll(RegExp(r'\(\s+'), '(');
    text = text.replaceAll(RegExp(r'\s+\)'), ')');
    text = text.replaceAll(RegExp(r'\s{2,}'), ' ');
    text = text.replaceAll(RegExp(r' *\n *'), '\n');
    text = text.replaceAll(RegExp(r'([.!?…]){2,}'), r'$1');
    text = text.replaceAll(RegExp(r'([,;:]){2,}'), r'$1');
    return text.trim();
  }

  String _capitalizeSentenceStarts(String input) {
    final chars = input.split('');
    final out = StringBuffer();
    var shouldCapitalize = true;

    for (final ch in chars) {
      if (shouldCapitalize && RegExp(r'[A-Za-zÀ-ÿ]').hasMatch(ch)) {
        out.write(ch.toUpperCase());
        shouldCapitalize = false;
        continue;
      }

      out.write(ch);

      if (RegExp(r'[.!?…\n]').hasMatch(ch)) {
        shouldCapitalize = true;
      } else if (!RegExp(r'\s').hasMatch(ch)) {
        shouldCapitalize = false;
      }
    }

    return out.toString();
  }

  List<String> _chunkText(String text, {required int maxChunkChars}) {
    final t = text.trim();
    if (t.length <= maxChunkChars) return [t];

    final paras = t.split(RegExp(r'\n\s*\n'));
    final chunks = <String>[];
    var buffer = StringBuffer();

    void flush() {
      final s = buffer.toString().trim();
      if (s.isNotEmpty) chunks.add(s);
      buffer = StringBuffer();
    }

    for (final para in paras) {
      final p = para.trim();
      if (p.isEmpty) continue;

      if (p.length > maxChunkChars) {
        if (buffer.isNotEmpty) flush();
        final sentences = p.split(RegExp(r'(?<=[\.\!?。！？])\s+'));
        var local = StringBuffer();
        for (final sentence in sentences) {
          if (local.length + sentence.length + 1 > maxChunkChars) {
            final s = local.toString().trim();
            if (s.isNotEmpty) chunks.add(s);
            local = StringBuffer();
          }
          local.write(sentence);
          local.write(' ');
        }
        final last = local.toString().trim();
        if (last.isNotEmpty) chunks.add(last);
        continue;
      }

      if (buffer.length + p.length + 2 > maxChunkChars) flush();
      buffer.write(p);
      buffer.write('\n\n');
    }

    flush();
    return chunks.isEmpty ? [t] : chunks;
  }
}
